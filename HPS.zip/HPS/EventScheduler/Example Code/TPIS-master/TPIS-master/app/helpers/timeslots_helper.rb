module TimeslotsHelper
end
