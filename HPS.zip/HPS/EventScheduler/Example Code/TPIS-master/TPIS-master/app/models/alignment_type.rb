class AlignmentType < ApplicationRecord
end
