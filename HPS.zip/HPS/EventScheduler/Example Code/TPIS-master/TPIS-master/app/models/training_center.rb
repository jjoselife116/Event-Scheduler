class TrainingCenter < ApplicationRecord
  has_many :faculty
end
