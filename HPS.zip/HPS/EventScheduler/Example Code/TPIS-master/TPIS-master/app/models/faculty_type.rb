class FacultyType < ApplicationRecord
  has_many :faculties
end
