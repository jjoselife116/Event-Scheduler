class Timeslot < ApplicationRecord
end
