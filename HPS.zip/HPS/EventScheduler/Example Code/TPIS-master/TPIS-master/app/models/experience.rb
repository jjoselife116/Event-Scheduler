class Experience < ApplicationRecord
  belongs_to :candidate
end
