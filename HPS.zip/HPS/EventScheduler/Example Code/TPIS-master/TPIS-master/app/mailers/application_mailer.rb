class ApplicationMailer < ActionMailer::Base
  default from: 'lordwarmandfuzzies@pillowland.com'
  layout 'mailer'
end
