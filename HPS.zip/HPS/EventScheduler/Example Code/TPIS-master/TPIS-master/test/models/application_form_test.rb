require 'test_helper'

class ApplicationFormTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
