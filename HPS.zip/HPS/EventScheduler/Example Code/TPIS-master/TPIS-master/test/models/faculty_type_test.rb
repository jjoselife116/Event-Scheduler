require 'test_helper'

class FacultyTypeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
