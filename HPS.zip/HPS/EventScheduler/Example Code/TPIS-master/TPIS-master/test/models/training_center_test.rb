require 'test_helper'

class TrainingCenterTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
