# README

# TPIS - "Therapeutic Professionals Information System"


# What is this program?
* This program is created by Sleight Data Consulting for Therapeutic Professionals.
* This program is meant to replace the process of Instructor Candidate recruiting and improve business flow.

## What functionality does this program provide?
* This program will allow a candidate to declare interest in the company by applying through the web application.
* The Instructor Candidate will create a profile on the website that will track their information and streamline the application process.
* After applying and being acknowledged on the admin side of the program, an interview will be tracked through the program.
* At each step of the process illustrated of this program, an email will be automatically sent to track a candidate as they move through the process.
* This program is a small portion of the scope of the overall company website.



## Sleight Data Consulting is:
* Emely Sheng - Project Manager
* Daniel Villarreal - Assistant Project Manager
* Joshua Joseph
* Tin Van
* Avishka Dalal
* Husnain Khadir





Things you may want to cover:

* Ruby version - 2.4.0p

* System dependencies - Gems described in the gemfile.

* Configuration

* Database creation

* Database initialization

* How to run the test suite

* Services (job queues, cache servers, search engines, etc.)

* Deployment instructions

* ...
